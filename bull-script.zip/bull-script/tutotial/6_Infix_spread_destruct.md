# 6 Infix, spread, destruct

## Infix

```
fun my_infix_fun arr {
    arr[0] + arr[1];
}

fun main _ {
    x = 1 my_infix_fun 2;
    // expression "a b c" is equivalent to "b (a,c)"

    x = 1 my_infix_fun 2 my_infix_fun 3 my_infix_fun 4;
    // 1 mif 2 mif 3 mif 4 === ((1 mif 2) mif 3) mif 4)

    0;
}
```

## Spread

```
fun spread [zeroth, first, second] {
    zeroth + first + second;
}

/// is equivalent to
//
// fun spread arg {
//     zeroth = arg[0];
//     first = arg[1];
//     secodn = arg[2];
//     zeroth + first + second;
// }
```

## Destruct

```
fun destruct { a: ok; b: value; } {
    if b then b else 0;
}

/// is equivalen to
// fun destruct arg {
//     a = arg.ok;
//     b = arg.value;
//     if b then b else 0;
// }
```

[1 Hello world](./1_Hello_world.md)

[2 Types](./2_Types.md)

[3 Operators](./3_Operators.md)

[4 Flow control](./4_Flow_control.md)

[5 Functions and globals](./5_Functions_globals.md)

[6 Infix, spread, destruct](./6_Infix_spread_destruct.md)

[7 Closures](./7_Closures.md)

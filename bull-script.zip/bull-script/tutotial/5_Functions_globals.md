# 5 Functions and global variables

```
// function always take exactly 1 argument
fun my_fun i {
    res = i * i;
    res = res - 1;
    res; // last expression in function body is return value
}

fun higher_order fun_to_be_applied_to_zero {
    fun_to_be_applied_to_zero 0;
}

fun main _ {
    x = my_fun 1;
    // invoking function is just "fun_name arg", 
    // parenthesis are optional
    // my_fun (1) is equivalent to expression above
    y = my_fun 2;
    z = my_fun 3;

    w = higher_oreder my_fun;
    // fun can be assigned to varialbe or passed as argument

    0;
}
```

```
var global_variable = 17
var other_global = 11
```

# 1 Hello world

```
// comments

# std/io.txt; // import io from standard library

fun main _ {
    print_l "hello world";
    0; // program exit code
}
```

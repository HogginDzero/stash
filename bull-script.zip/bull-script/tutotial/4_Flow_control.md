# 4 Flow control

```
fun main _ {
    x = if true then 11 else 13; // "if" is an expression

    x = if true then {
        res = 11;
        res = res * 3;
        res = res / 17;
        res;
    } else 0;
    // block is also an expression, equivalent to it's last statement
    
    if true then { 0; }; // else is optional
    
    i = 0;
    x = while i < 10 do {
        i = i + 1;
    } else -1;
    // "while" is also an expression
    // equivalent to last statement of it's body on last iteration
    // or else branch if body was never entered

    0;
}
```
# 2 Types

```
# std/bool.txt;
# std/array.txt;

fun main _ {
    string = "string"; // double quotes
    character = 'a'; // singular quotes
    integer = 13; // just plain int
    bool = true; // or false

    object = new; // create new object
    object.name = "Ann"; // set it's fields
    object.age = 30;
    
    // alternatively, same effect as above
    object_sugar = new {
        name: "Ann";
        age: 30;
    };

    other_object = new;
    other_object[0] = 11; // object also has elements like array does

    array = Array.sized 10; // actual array

    array_litreal = 1,2,3,4,5;

    0;
}
```

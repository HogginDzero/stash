# 3 Operators

```
fun main _ {
    int_res = (2 + 2 * 2) * 10 / 7 % 8;
    bool_res = 14 >= 17 | 1 < 2 & 2 < 3;
    logical_not = !bool_res;
    bitwise_not = ~int_res;
    0;
}
```

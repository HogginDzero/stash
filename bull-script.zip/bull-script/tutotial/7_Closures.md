# 7 Closures

```
fun create_fun_adding_three _ {
    res = fn a { a + 3; };  // inline fn expression

    spread_example = fn [left, right] { left + fight; };

    destruct_example = fn {left: ok; right: value;} { left + fight; };

    res;
}

```

```
// function is object, it can also have fields
// which allows to manually create closures

fun create_fun_adding number {
    res = fn a { a + this.number; }; // this references to fn
    res.number = number; // manually closing over nubmer
    res;
}

fun main _ {
    add = create_fun_adding 13;
    res = add 7;
    0;
}
```

fun main arg {
    // мейн 
    // арг пока ничего не делает

    invocation_example 0;
    types_example 0;
    ops_example 0;
    if_example 0;
    while_example 0;
    infix_example 0;
    closure_example 0;

    // последнее выражение в теле - то что ретурнится
    0 ;
}

fun print_h_w _ {
    // аргумент всегда ровно 1
    // не нужный арг можно обозначать _

    printSL "hello world";
    // print / printL - печатает int
    // printS / printSL - печатает string

    0;
}


fun invocation_example _ {
    printSL "invocation example";
    // чтобы вызвать функцию достаточно написать "функция арг"
    print_h_w 0;
}


fun types_example _ {
    printSL "types example";
    int = 13;
    char = 'a';
    string = "hi";

    object = new;
    object.name = "Ann";
    object.age = 30;
    object;

    // массив это объект
    array = new; 
    array[-1] = 2; // по -1 индексу хранится размер массива
    array[0] = 11;
    array[1] = 13;
    array;

    // фукнции это массивы с их байткодом
    fun_ref = main; 
    printL fun_ref[-1];

    0;
}

fun ops_example _ {
    printSL "ops example";
    // +-
    // */%
    // & ^ |
    // ! логическое не, ~ битовое не

    printL (2 + 2 * 2) * 10 / 7 % 8;
    printL 14 >= 11;
    printL 3 & 5 | 7;
    printL !1;
    printL ~1;
    0;
}

fun if_example _ {
    printSL "if example";
    flag = 1;
    if flag then {
        printSL "true";
    } else {
        printSL "false";
    }; // ; после нужна

    // if это выражение
    res = if flag then 100 else 10;
    0;
}

fun while_example _ {
    printSL "while example";
    i = 0;
    while i < 10 do {
        printL i;
        i = i + 1;
    } else {
        printSL "error"; // выполнится если в цикл не удалось зайти ни разу
    }; // ; нужен

    // while это выражение, равно последнему выражению в теле или в ветке else
    res = while i < 10 do { i = i + 1; i; } else 0;
}

fun infix_example _ {
    printSL "infix example";
    // инфиксный вызов функции infix_fun
    13 infix_fun 31;

    13 infix_fun 31 infix_fun 17 infix_fun 67;
    // ( (13 infix_fun 31) infix_fun 17) infix_fun 67;
}

fun infix_fun args {
    left = args[0];
    right = args[1];
    res = left + right;
    printL res;
    res;
}


fun closure_example _ {
    printSL "closure example";
    plus_five = create_closure 5;
    plus_seven = create_closure 7;
    printL (plus_five 10);
    printL (plus_seven 10);
}

fun create_closure captured_value {
    res = clone closure_body;
    res.captured = captured_value;
    res;
}

fun closure_body arg {
    this.captured + arg;
}
